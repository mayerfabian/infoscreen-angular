import { Component } from '@angular/core';

@Component({
  selector: 'app-rest-mode',
  imports: [],
  templateUrl: './rest-mode.component.html',
  styleUrl: './rest-mode.component.scss'
})
export class RestModeComponent {

}
