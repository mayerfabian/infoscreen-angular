export const environment = {
  web:
    {
      client_id:"572454934069-sk9tgkb7lh8tfuest6rvp32iouhpm3jb.apps.googleusercontent.com",
      project_id:"calenderapi-474608",
      auth_uri:"https://accounts.google.com/o/oauth2/auth",
      token_uri:"https://oauth2.googleapis.com/token",
      auth_provider_x509_cert_url:"https://www.googleapis.com/oauth2/v1/certs",
      client_secret:"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",
      redirect_uris:"http://localhost:4200/redirect",
      javascript_origins:["http://localhost:4200/"]
    }
}
