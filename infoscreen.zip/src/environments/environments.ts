export const environment = {
  production: false,
  GOOGLE_STREETVIEW_KEY: 'AIzaSyDrLRj2R8OSidh087Wn_NKF9e2rrlo0qdk'
};
