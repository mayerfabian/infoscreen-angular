import {
  Component,
  OnInit,
  OnDestroy,
  Type,
  ChangeDetectorRef,
  ChangeDetectionStrategy,
  Input,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { filter, Subject, takeUntil } from 'rxjs';

import { ModeService } from '../mode.service';
import type { Einsatz } from '../models/lea.interfaces';

import { AlarmV1Component } from './alarm-v1/alarm-v1.component';
import { AlarmV2Component } from './alarm-v2/alarm-v2.component';
import { HeaderControlsComponent } from '../shared/header-controls/header-controls/header-controls.component';

type Variant = 'v1' | 'v2';

@Component({
  selector: 'app-incident-mode',
  standalone: true,
  imports: [CommonModule, AlarmV1Component, AlarmV2Component,HeaderControlsComponent],
  templateUrl: './incident-mode.component.html',
  styleUrls: ['./incident-mode.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class IncidentModeComponent implements OnInit, OnDestroy {
  /** NEU: Variante kann vom Parent (Infoscreen) gesetzt werden */
  @Input() variant?: Variant;

  /** aktuell aktive Darstellung (V1/V2) */
  activeCmp!: Type<any>;

  /** Inputs für ngComponentOutlet */
  outletInputs: Record<string, any> = {};

  /** aktuell angezeigter Einsatz */
  einsatz: Einsatz | null = null;

  /** Live-Uhrzeit für Timer/Elapsed */
  now = new Date();
  private clockHandle: any;

  private destroy$ = new Subject<void>();
  private pollHandle: any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef,
    public modeService: ModeService
  ) {}

  ngOnInit(): void {
    // Variante (V1/V2) initial + bei Navigation/Query wechseln
    this.activeCmp = this.resolveVariantFromUrl(this.router.url, this.route);

    this.router.events
      .pipe(filter((e) => e instanceof NavigationEnd), takeUntil(this.destroy$))
      .subscribe(() => {
        this.activeCmp = this.resolveVariantFromUrl(this.router.url, this.route);
        this.pushInputs();
      });

    this.route.queryParamMap
      .pipe(takeUntil(this.destroy$))
      .subscribe(() => {
        this.activeCmp = this.resolveVariantFromUrl(this.router.url, this.route);
        this.pushInputs();
      });

    // Einsatzdaten: bevorzugt Observable einsatz$, sonst Fallback-Polling
    const asAny = this.modeService as any;
    if (asAny && typeof asAny['einsatz$']?.subscribe === 'function') {
      asAny['einsatz$']
        .pipe(takeUntil(this.destroy$))
        .subscribe((val: Einsatz[] | Einsatz | null | undefined) => {
          this.einsatz = Array.isArray(val) ? (val[0] ?? null) : (val ?? null);
          this.pushInputs();
        });
    } else {
      this.refreshEinsatz(); // initial
      this.pollHandle = setInterval(() => this.refreshEinsatz(), 500);
    }

    // Uhr jede Sekunde aktualisieren (für elapsed)
    this.clockHandle = setInterval(() => {
      this.now = new Date();
      this.cdr.markForCheck();
    }, 1000);

    // erste Inputs setzen
    this.pushInputs();
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
    if (this.pollHandle) clearInterval(this.pollHandle);
    if (this.clockHandle) clearInterval(this.clockHandle);
  }

  /** Buttons im Header */
  go(view: 'v1' | 'v2'): void {
    this.router.navigate([view === 'v1' ? '/alarm' : '/alarm2']);
  }

  isActive(view: 'v1' | 'v2'): boolean {
    const url = (this.router.url || '').toLowerCase();
    if (view === 'v1') return url.includes('/alarm') && !url.includes('/alarm2');
    return url.includes('/alarm2');
  }

  /** liest aus dem ModeService-Signal das erste Element */
  private refreshEinsatz(): void {
    try {
      const list = this.modeService.einsaetze?.() ?? [];
      const next: Einsatz | null = (list && list.length) ? list[0] : null;
      const changed = (this.einsatz?.id !== next?.id) || (!!this.einsatz !== !!next);
      if (changed) {
        this.einsatz = next;
        this.pushInputs();
      }
    } catch {
      /* ignore */
    }
  }

  /** Inputs für das ngComponentOutlet aktualisieren */
  private pushInputs(): void {
    this.outletInputs = { einsatz: this.einsatz, now: this.now };
    this.cdr.markForCheck();
  }

  /**
   * Route → Komponententyp (V1/V2)
   * Priorität:
   * 0) @Input() variant (vom Parent übergeben)
   * 1) ?view=v1|v2
   * 2) ?incident=v1|v2
   * 3) Pfad /alarm2
   * 4) Route-Data { variant: 'v2' }
   * 5) Default V1
   */
  private resolveVariantFromUrl(url: string, r: ActivatedRoute): Type<any> {
    // (0) Parent-Input hat Vorrang
    if (this.variant === 'v2') return AlarmV2Component;
    if (this.variant === 'v1') return AlarmV1Component;

    const qpView = (r.snapshot.queryParamMap.get('view') || '').toLowerCase();
    if (qpView === 'v2') return AlarmV2Component;
    if (qpView === 'v1') return AlarmV1Component;

    const qpIncident = (r.snapshot.queryParamMap.get('incident') || '').toLowerCase();
    if (qpIncident === 'v2') return AlarmV2Component;
    if (qpIncident === 'v1') return AlarmV1Component;

    const lower = (url || '').toLowerCase();
    if (lower.includes('/alarm2')) return AlarmV2Component;

    const dataVariant = (r.snapshot.data?.['variant'] as Variant | undefined);
    if (dataVariant === 'v2') return AlarmV2Component;

    return AlarmV1Component;
  }

  /** Vergangene Zeit seit Alarm als HH:mm:ss */
  elapsed(e: Einsatz | null | undefined): string {
    if (!e?.alarmtime) return '—';
    const ms = Math.max(0, this.now.getTime() - e.alarmtime);
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }

  /** Überschrift: Typ + Text, fallback "ALARM" */
  meldebild(e?: Einsatz): string {
    if (!e) return 'ALARM';
    const typ = (e.eventtype || '').trim();
    const text = (e.eventtypetext || '').trim();
    return (typ && text) ? `${typ} – ${text}` : (typ || text || 'ALARM');
  }
}
